### Hexlet tests and linter status:
[![Actions Status](https://github.com/VladimirKonts/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/VladimirKonts/python-project-49/actions)

<a href="https://codeclimate.com/github/VladimirKonts/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b35376b90c535c9f4905/maintainability" /></a>