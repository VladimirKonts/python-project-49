### Hexlet tests and linter status:
[![Actions Status](https://github.com/VladimirKonts/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/VladimirKonts/python-project-49/actions)

<a href="https://codeclimate.com/github/VladimirKonts/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b35376b90c535c9f4905/maintainability" /></a>

[![asciicast](https://asciinema.org/a/M2xCmbPwfCn2uSFVs5W67Euak.svg)](https://asciinema.org/a/M2xCmbPwfCn2uSFVs5W67Euak)

[![asciicast](https://asciinema.org/a/cOVosXw1uzNjwJc1kcIPvz7HT.svg)](https://asciinema.org/a/cOVosXw1uzNjwJc1kcIPvz7HT)

[![asciicast](https://asciinema.org/a/JmDI89xdVIhHemXQYzXiKXxun.svg)](https://asciinema.org/a/JmDI89xdVIhHemXQYzXiKXxun)

[![asciicast](https://asciinema.org/a/YWYFCNjYtZwGQTFvLlaOG7hLZ.svg)](https://asciinema.org/a/YWYFCNjYtZwGQTFvLlaOG7hLZ)
