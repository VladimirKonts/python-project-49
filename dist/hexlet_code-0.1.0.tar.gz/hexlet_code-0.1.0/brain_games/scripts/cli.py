from prompt_toolkit import prompt

name = prompt('May I have your name? ')