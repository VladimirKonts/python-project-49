#!/usr/bin/env python3
def show_greeting():
    text = 'Welcome to the Brain Games!'
    print(text)

show_greeting()    

if __name__ == '__main__':
    main()
